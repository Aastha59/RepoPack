@title Central Middle � Derived Assessment
@description Two generated quantitative math questions similar to the base examples.

// Question 1
@question Each student at Riverside Prep chooses a uniform consisting of 1 shirt, 1 pair of pants, and 1 hat. The table shows the available options for each item. How many different complete uniforms are possible?
@instruction Select the number of possible uniform combinations from the options.
@difficulty easy
@Order 1
@option (A) 18
@option (B) 24
@@option (C) 36
@option (D) 48
@option (E) 72
@explanation 
There are 4 shirt choices, 3 pants choices, and 3 hat choices. Total combinations = 4 � 3 � 3 = 36.
@subject Quantitative Math
@unit Numbers and Operations
@topic Combinations / Counting
@plusmarks 1

// Question 2
@question The top view of a rectangular box containing 8 identical tightly packed spherical balls arranged in two rows of four is shown. If each ball has radius $2$ cm, which of the following is closest to the dimensions (height � width � length), in centimeters, of the rectangular package?
@instruction Choose the correct dimensions from the options.
@difficulty moderate
@Order 2
@option (A) $4 \times 8 \times 16$
@option (B) $2 \times 8 \times 16$
@@option (C) $4 \times 12 \times 18$
@option (D) $6 \times 8 \times 16$
@option (E) $8 \times 12 \times 24$
@explanation 
Top view shows two rows and four columns of circles (diameter = 4 cm). Width (short side) = 2 rows � 4 cm = 8 cm. Length = 4 columns � 4 cm = 16 cm. Height must accommodate one layer of balls: diameter = 4 cm. So dimensions: $4 \times 8 \times 16$.
@subject Quantitative Math
@unit Geometry and Measurement
@topic Solid Figures / Coordinate Geometry
@plusmarks 1
