# Generated Assessment Questions

This repository contains two generated quantitative math questions in the requested Question Output Format, plus images.
